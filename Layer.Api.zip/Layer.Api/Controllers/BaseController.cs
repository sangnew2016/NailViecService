﻿using System.Web.Http;

namespace Layer.Api.Controllers
{
    public class BaseController: ApiController
    {
    }
}